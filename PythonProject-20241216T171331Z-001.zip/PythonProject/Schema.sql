
customers_list = ['custno','firstname','lastname','gender','age','profession','contactNo',
'emailId','city','state','isActive','createdDate','UpdatedDate']

products_list = ['productno','productName','Description','isActive','createdDate','UpdatedDate']

transactions_list = ['txnno','txndate','custno','amount','productno','spendby']







